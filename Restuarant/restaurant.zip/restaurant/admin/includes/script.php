
<script src="../public/assets/js/admin.js"></script>