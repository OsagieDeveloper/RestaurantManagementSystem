## Restaurant Management System
This is the procedure of running this project

create a database and name it reservation
import the reservation.sql database file

staff login
email: james@gmail.com
password: Liquid@001

admin login
email: admin@gmail.com
password: Liquid@001

